-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema proiect
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema proiect
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `proiect` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `proiect` ;

-- -----------------------------------------------------
-- Table `proiect`.`policlinici`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `proiect`.`policlinici` (
  `ID_Policlinica` INT NOT NULL,
  `Denumire` VARCHAR(100) NOT NULL,
  `Adresa` VARCHAR(255) NOT NULL,
  `Profit` INT NULL DEFAULT NULL,
  PRIMARY KEY (`ID_Policlinica`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `proiect`.`utilizatori`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `proiect`.`utilizatori` (
  `ID_Utilizator` INT NOT NULL,
  `CNP` VARCHAR(13) NOT NULL,
  `Parola` VARCHAR(45) NOT NULL,
  `Nume` VARCHAR(50) NOT NULL,
  `Prenume` VARCHAR(50) NOT NULL,
  `Adresa` VARCHAR(255) NOT NULL,
  `Telefon` VARCHAR(15) NOT NULL,
  `Email` VARCHAR(100) NOT NULL,
  `Cont_IBAN` VARCHAR(30) NOT NULL,
  `Numar_Contract` INT NOT NULL,
  `Data_Angajarii` DATE NOT NULL,
  `ID_Policlinica` INT NULL DEFAULT NULL,
  `rol_user` ENUM('admin', 'superadmin', 'pacient', 'medic', 'asistent', 'hr', 'economic', 'receptioner') NOT NULL,
  PRIMARY KEY (`ID_Utilizator`),
  UNIQUE INDEX `CNP_UNIQUE` (`CNP` ASC) VISIBLE,
  UNIQUE INDEX `parola_UNIQUE` (`Parola` ASC) VISIBLE,
  INDEX `ID_Policlinica` (`ID_Policlinica` ASC) VISIBLE,
  CONSTRAINT `utilizatori_ibfk_1`
    FOREIGN KEY (`ID_Policlinica`)
    REFERENCES `proiect`.`policlinici` (`ID_Policlinica`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `proiect`.`angajati`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `proiect`.`angajati` (
  `ID_Angajat` INT NOT NULL,
  `ID_Utilizator` INT NULL DEFAULT NULL,
  `Salariu` DECIMAL(10,2) NOT NULL,
  `Ore_Lucrate` INT NOT NULL,
  `Tip_Angajati` ENUM('HR', 'RECEPTIONER', 'ECONOMIC', 'ASISTENT', 'MEDIC', 'ADMIN', 'SUPERADMIN') NULL DEFAULT NULL,
  PRIMARY KEY (`ID_Angajat`),
  INDEX `FK_Angajati_Utilizatori` (`ID_Utilizator` ASC) VISIBLE,
  CONSTRAINT `FK_Angajati_Utilizatori`
    FOREIGN KEY (`ID_Utilizator`)
    REFERENCES `proiect`.`utilizatori` (`ID_Utilizator`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci
KEY_BLOCK_SIZE = 4;


-- -----------------------------------------------------
-- Table `proiect`.`asistentimedicali`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `proiect`.`asistentimedicali` (
  `ID_Asistent` INT NOT NULL,
  `ID_Angajat` INT NULL DEFAULT NULL,
  `Tip_Asistent` VARCHAR(20) NOT NULL,
  `Grad_Asistent` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`ID_Asistent`),
  INDEX `FK_AsistentiMedicali_Angajati` (`ID_Angajat` ASC) VISIBLE,
  CONSTRAINT `FK_AsistentiMedicali_Angajati`
    FOREIGN KEY (`ID_Angajat`)
    REFERENCES `proiect`.`angajati` (`ID_Angajat`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `proiect`.`medici`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `proiect`.`medici` (
  `ID_Medic` INT NOT NULL,
  `ID_Angajat` INT NULL DEFAULT NULL,
  `Specialitate` VARCHAR(50) NOT NULL,
  `Grad_Medic` VARCHAR(20) NOT NULL,
  `Cod_Parafa` VARCHAR(20) NOT NULL,
  `Competente` VARCHAR(255) NOT NULL,
  `Titlu_Stiintific` VARCHAR(50) NULL DEFAULT NULL,
  `Post_Didactic` VARCHAR(50) NULL DEFAULT NULL,
  `Procent_Servicii` DECIMAL(5,2) NOT NULL,
  PRIMARY KEY (`ID_Medic`),
  INDEX `FK_Medici_Angajati` (`ID_Angajat` ASC) VISIBLE,
  CONSTRAINT `FK_Medici_Angajati`
    FOREIGN KEY (`ID_Angajat`)
    REFERENCES `proiect`.`angajati` (`ID_Angajat`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `proiect`.`pacienti`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `proiect`.`pacienti` (
  `ID_Pacient` INT NOT NULL,
  `ID_Utilizator` INT NULL DEFAULT NULL,
  PRIMARY KEY (`ID_Pacient`),
  INDEX `FK_Pacienti_Utilizatori` (`ID_Utilizator` ASC) VISIBLE,
  CONSTRAINT `FK_Pacienti_Utilizatori`
    FOREIGN KEY (`ID_Utilizator`)
    REFERENCES `proiect`.`utilizatori` (`ID_Utilizator`)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `proiect`.`programari`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `proiect`.`programari` (
  `ID_Programare` INT NOT NULL,
  `ID_Pacient` INT NULL DEFAULT NULL,
  `ID_Medic` INT NULL DEFAULT NULL,
  `Data_Programare` DATE NOT NULL,
  `Ora_Programare` INT NOT NULL,
  `ID_Serviciu` INT NULL DEFAULT NULL,
  PRIMARY KEY (`ID_Programare`),
  INDEX `FK_Programari_Pacienti` (`ID_Pacient` ASC) VISIBLE,
  INDEX `FK_Programari_Medici` (`ID_Medic` ASC) VISIBLE,
  CONSTRAINT `FK_Programari_Medici`
    FOREIGN KEY (`ID_Medic`)
    REFERENCES `proiect`.`medici` (`ID_Medic`)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT,
  CONSTRAINT `FK_Programari_Pacienti`
    FOREIGN KEY (`ID_Pacient`)
    REFERENCES `proiect`.`pacienti` (`ID_Pacient`)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb3;


-- -----------------------------------------------------
-- Table `proiect`.`bonurifiscale`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `proiect`.`bonurifiscale` (
  `ID_Bon` INT NOT NULL,
  `ID_Programare` INT NULL DEFAULT NULL,
  `Data_Emitere` DATE NOT NULL,
  `Valoare` DECIMAL(8,2) NOT NULL,
  `ID_Policlinica` INT NULL DEFAULT NULL,
  PRIMARY KEY (`ID_Bon`),
  INDEX `FK_BonuriFiscale_Programari` (`ID_Programare` ASC) VISIBLE,
  CONSTRAINT `FK_BonuriFiscale_Programari`
    FOREIGN KEY (`ID_Programare`)
    REFERENCES `proiect`.`programari` (`ID_Programare`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `proiect`.`programpoliclinica`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `proiect`.`programpoliclinica` (
  `ID_Program` INT NOT NULL,
  `ID_Policlinica` INT NULL DEFAULT NULL,
  `Zi_Saptamana` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`ID_Program`),
  INDEX `FK_ProgramPoliclinica_Policlinici` (`ID_Policlinica` ASC) VISIBLE,
  CONSTRAINT `FK_ProgramPoliclinica_Angajat`
    FOREIGN KEY (`ID_Program`)
    REFERENCES `proiect`.`angajati` (`ID_Angajat`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `FK_ProgramPoliclinica_Policlinici`
    FOREIGN KEY (`ID_Policlinica`)
    REFERENCES `proiect`.`policlinici` (`ID_Policlinica`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `proiect`.`rapoartemedicale`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `proiect`.`rapoartemedicale` (
  `ID_Raport` INT NOT NULL,
  `ID_Programare` INT NULL DEFAULT NULL,
  `Continut` TEXT NOT NULL,
  `ID_Asistent` INT NOT NULL,
  `ID_Medic` INT NOT NULL,
  PRIMARY KEY (`ID_Raport`),
  INDEX `FK_RapoarteMedicale_Programari` (`ID_Programare` ASC) VISIBLE,
  INDEX `FK_Asistent_idx` (`ID_Asistent` ASC) VISIBLE,
  INDEX `FK_Raport_Medic` (`ID_Medic` ASC) VISIBLE,
  CONSTRAINT `FK_Asistent`
    FOREIGN KEY (`ID_Asistent`)
    REFERENCES `proiect`.`asistentimedicali` (`ID_Asistent`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `FK_RapoarteMedicale_Programari`
    FOREIGN KEY (`ID_Programare`)
    REFERENCES `proiect`.`programari` (`ID_Programare`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `FK_Raport_Medic`
    FOREIGN KEY (`ID_Medic`)
    REFERENCES `proiect`.`medici` (`ID_Medic`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `proiect`.`serviciidisponibile`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `proiect`.`serviciidisponibile` (
  `ID_ServiciiDisponibile` INT NOT NULL,
  `Grad` INT NOT NULL,
  `Cost` INT NOT NULL,
  `Durata` INT NOT NULL,
  PRIMARY KEY (`ID_ServiciiDisponibile`),
  INDEX `Grad_idx` (`Grad` ASC) VISIBLE,
  CONSTRAINT `FK_Serviciu_Programare`
    FOREIGN KEY (`ID_ServiciiDisponibile`)
    REFERENCES `proiect`.`programari` (`ID_Programare`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `GradulMedicului`
    FOREIGN KEY (`Grad`)
    REFERENCES `proiect`.`medici` (`ID_Medic`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `proiect`.`serviciispecifice`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `proiect`.`serviciispecifice` (
  `ID_SerciviiSpecifice` INT NOT NULL,
  `NumeSpecialitate` VARCHAR(45) NOT NULL,
  `CompetenteleMedicului` INT NOT NULL,
  `PretulServiciului` INT NOT NULL,
  `DurataServiciului` INT NOT NULL,
  PRIMARY KEY (`ID_SerciviiSpecifice`),
  INDEX `ID_Competente_idx` (`CompetenteleMedicului` ASC) VISIBLE,
  CONSTRAINT `ID_Competente`
    FOREIGN KEY (`CompetenteleMedicului`)
    REFERENCES `proiect`.`medici` (`ID_Medic`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;

USE `proiect` ;

-- -----------------------------------------------------
-- procedure CalculProfitMedic
-- -----------------------------------------------------

DELIMITER $$
USE `proiect`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `CalculProfitMedic`(IN medicID INT)
BEGIN
    DECLARE medicProfit DECIMAL(10,2);

    SELECT SUM(p.Valoare * m.Procent_Servicii / 100) INTO medicProfit
    FROM proiect.medici m
    JOIN proiect.programari pr ON m.ID_Medic = pr.ID_Medic
    JOIN proiect.bonurifiscale p ON pr.ID_Programare = p.ID_Programare
    WHERE m.ID_Medic = medicID;

    SELECT medicProfit AS ProfitMedic;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure CalculProfitPoliclinica2
-- -----------------------------------------------------

DELIMITER $$
USE `proiect`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `CalculProfitPoliclinica2`(IN medicID INT)
BEGIN
    DECLARE policlinicaProfit DECIMAL(10, 2);

    -- Calculează profitul policlinicii pentru medic
    SELECT SUM(p.Valoare) AS ProfitPoliclinica
    INTO policlinicaProfit
    FROM proiect.programari pr
    JOIN proiect.bonurifiscale p ON pr.ID_Programare = p.ID_Programare
    WHERE pr.ID_Medic = medicID;

    -- Afișează profitul policlinicii pentru medic
    SELECT policlinicaProfit AS ProfitPoliclinica;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure CalculSalariuOra5
-- -----------------------------------------------------

DELIMITER $$
USE `proiect`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `CalculSalariuOra5`(IN medicID INT)
BEGIN
    DECLARE salariuLunar DECIMAL(10, 2);
    DECLARE oreLucrate INT;
    DECLARE salariuOra DECIMAL(10, 2);

    -- Obține salariul lunar al medicului
    SELECT Salariu INTO salariuLunar
    FROM proiect.medici m
    JOIN proiect.angajati a ON m.ID_Angajat = a.ID_Angajat
    WHERE m.ID_Medic = medicID;

    -- Obține numărul de ore lucrate de medic
    SELECT Ore_Lucrate INTO oreLucrate
    FROM proiect.angajati
    WHERE ID_Angajat = medicID;

    -- Tratează cazurile când oreLucrate este null sau zero
    IF oreLucrate IS NULL OR oreLucrate = 0 THEN
        SET salariuOra = 0;
    ELSE
        -- Calculează salariul pe oră
        SET salariuOra = salariuLunar / oreLucrate;
    END IF;

    -- Afișează sau returnează salariul pe oră
    SELECT salariuOra AS SalariuOra;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure SelectSalariuAngajat
-- -----------------------------------------------------

DELIMITER $$
USE `proiect`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SelectSalariuAngajat`(IN utilizatorID INT)
BEGIN
    SELECT u.nume, u.prenume, a.salariu
    FROM proiect.utilizatori u
    JOIN proiect.angajati a ON u.ID_Utilizator = a.ID_Utilizator
    WHERE u.ID_Utilizator = utilizatorID;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure SelectUtilizator
-- -----------------------------------------------------

DELIMITER $$
USE `proiect`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SelectUtilizator`(IN utilizatorID INT)
BEGIN
    SELECT Nume, Prenume, CNP, rol_user, Email, Adresa, Telefon, Cont_IBAN, Numar_Contract, Data_Angajarii
    FROM proiect.utilizatori
    WHERE ID_Utilizator = utilizatorID;
END$$

DELIMITER ;
USE `proiect`;

DELIMITER $$
USE `proiect`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `proiect`.`actualizeaza_venit`
AFTER INSERT ON `proiect`.`bonurifiscale`
FOR EACH ROW
BEGIN
    DECLARE user_policlinica INT;

    -- Assuming that ID_Pacient uniquely identifies a patient in the pacienti table
    SELECT policlinici.ID_Policlinica INTO user_policlinica
    FROM policlinici
    JOIN bonurifiscale ON policlinici.ID_Policlinica = bonurifiscale.ID_Policlinica
    JOIN pacienti ON pacienti.ID_Pacient = NEW.ID_Programare
    WHERE bonurifiscale.ID_Programare = NEW.ID_Programare
    LIMIT 1;

    IF user_policlinica IS NOT NULL THEN
        -- Verificăm și actualizăm corect coloana corespunzătoare 
        UPDATE proiect.policlinici 
        SET Profit = Profit + NEW.Valoare 
        WHERE ID_Policlinica = user_policlinica;
    END IF;
END$$


DELIMITER ;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
