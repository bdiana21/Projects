INSERT INTO proiect.policlinici (ID_Policlinica, Denumire, Adresa) VALUES
(1,'Policlinica Centrala', 'Str. Principală nr. 1');


INSERT INTO proiect.utilizatori (ID_Utilizator,CNP, Parola, Nume, Prenume, Adresa, Telefon, Email, Cont_IBAN, Numar_Contract, Data_Angajarii, rol_user, ID_Policlinica) VALUES
(1,'1234567890123', 'parola1', 'Popescu', 'Ion', 'Str. Florilor nr. 3', '0721123456', 'popescu.ion@example.com', 'RO1234567890123456789012', 101, '2022-01-01', 'asistent',1),
(2,'9876543210987', 'parola2','Ionescu', 'Maria', 'Str. Verde nr. 7', '0722987654', 'ionescu.maria@example.com', 'RO9876543210987654321098', 102, '2022-02-15', 'medic', 1),
(3,'1111111111111', 'parola3','Clonta', 'Stefania', 'Str. Unirii nr. 10', '0722333444', 'clonta.stefania@example.com', 'RO1111111111111111111111', 103, '2022-03-20', 'receptioner', 1),
(4,'2222222222222','parola4','Dumitru', 'Ana', 'Str. Alba nr. 5', '0722555666', 'dumitru.ana@example.com', 'RO2222222222222222222222', 104, '2022-04-25', 'hr', 1),
(5,'3333333333333', 'parola5','Georgescu', 'Vasile', 'Str. Galbena nr. 12', '0722777888', 'georgescu.vasile@example.com', 'RO3333333333333333333333', 105, '2022-05-30', 'admin', 1),
(6,'4444444444444', 'parola6', 'Popescu', 'Iulian', 'Str. Florilor nr. 10', '0789214569', 'popescu.iulian@example.com', 'RO12345678901237895204', 105, '2022-02-02', 'superadmin',1),
(7,'5555555555555', 'parola7','Ionescu', 'Alexandra', 'Str. Verde nr. 8', '0722987664', 'ionescu.alexandra@example.com', 'RO9876543210987654398653', 104, '2022-05-20', 'economic', 1),
(8,'6666666666666', 'parola8','Jarda', 'Adina', 'Str. Test nr. 12', '0722333555', 'jarda.adina@example.com', 'RO1111111111111112222222', 99, '2022-03-21', 'pacient', 1),
(9,'1234567891234', 'parola9', 'Boitor', 'Diana', 'Str. Florilor nr. 7', '072112456', 'boitor.diana@example.com', 'RO123456789012345689456', 110, '2022-01-06', 'asistent',1),
(10, '7777777777777', 'parola10', 'Kulcsar', 'Noemi',  'Str. Zorilor nr, 120', '0768859769', 'k.noemi@example.com', 'RO123456789012340003479', 111, '2021-12-04', 'medic', 1),
(11, '8888888888888', 'parola11', 'Pop', 'Carina', 'Str. Apei nr. 76', '0741117328', 'pop.carina@example.com', 'RO000056789012340003479', 999, '2023-07-11', 'pacient', 1),
(12, '9999999999999', 'parola12', 'Stan', 'Mihaela', 'Str. Muresului, nr. 1', '0758859769', 'mihaela.stan@example.com', 'RO1111111111111113333222', 9999, '2024-01-01', 'pacient', 1),
(13, '1122334455667', 'parola13', 'Oltean', 'Dan', 'Str. Mioritei nr. 14', '0722960537', 'dan.oltean@example.com', 'RO3333333333333333123456', 99999, '2023-10-11', 'pacient', 1),
(14, '1357924681011', 'parola14', 'Danescu', 'Andrei', 'Str. Beriu nr. 45', '0753987254', 'andrei.danescu@example.com', 'RO1234567333333333123456', 999999, '2024-01-07', 'pacient', 1),
(15, '1727375797777', 'parola15', 'Blaj', 'Ana',  'Str. Observatorului nr, 129', '0768959719', 'ana.b@example.com', 'RO003450789002340003409', 119, '2021-05-20', 'medic', 1);


INSERT INTO proiect.angajati (ID_Angajat, Salariu, Ore_Lucrate, Tip_Angajati, ID_Utilizator) VALUES
( 1, 3000.00, 160, 'Asistent', 1),
( 2, 6000.00, 180, 'Medic', 2),
( 3, 2500.00, 160, 'Receptioner', 3),
( 4, 3500.00, 160, 'HR', 4),
( 5, 7500.00, 180, 'Medic', 5),
( 6, 15000.00, 200, 'Superadmin', 6),
( 7, 4000.00, 180, 'Economic', 7),
( 8, 3000.00, 160, 'Asistent', 9),
(10, 10000.00, 200, 'Medic', 10),
(15, 9000.00, 130, 'Medic', 11);


INSERT INTO proiect.asistentimedicali ( ID_Asistent, Tip_Asistent, Grad_Asistent, ID_Angajat) VALUES
(1, 'Generalist', 'I', 1),
(2, 'Chirurg', 'II', 8);


INSERT INTO proiect.medici (ID_Medic, ID_Angajat, Specialitate, Grad_Medic, Cod_Parafa, Competente, Titlu_Stiintific, Post_Didactic, Procent_Servicii) VALUES
(1, 2, 'Chirurgie', 'Primar', 'CP12345', 'Chirurgie generala', 'Doctor', 'Conferentiar', 30.00),
(2, 5, 'Ortopedie', 'Specialist', 'OP67890', 'Ortopedie si traumatologie', 'Doctor', NULL, 30.00),
(3, 10, 'Cardiologie', 'Primar', 'CD54321', 'Cardiologie', 'Profesor', 'Profesor universitar', 25.00);


INSERT INTO proiect.pacienti (ID_Pacient, ID_Utilizator) VALUES
(1, 8),
(2, 11),
(3, 12),
(4, 13),
(5, 14);


INSERT INTO proiect.programari (ID_Programare, ID_Pacient, Data_Programare, Ora_Programare, ID_Serviciu, ID_Medic) VALUES
(1, 1, '2022-01-10', '10', 1, 1),
(2, 2, '2022-02-15', '15', 2, 2),
(3, 3, '2022-03-20', '9', 3, 2),
(4, 4, '2022-04-25', '11', 1, 1),
(5, 5, '2022-05-30', '14', 2, 2);


INSERT INTO proiect.bonurifiscale ( ID_Bon, Data_Emitere, Valoare, ID_Programare) VALUES
(1, '2022-01-10', 150.00, 1),
(2, '2022-02-15', 200.00, 2),
(3, '2022-03-20', 1000.00, 3),
(4, '2022-04-25', 1120.00, 4),
(5, '2022-05-30', 1180.00, 5);



INSERT INTO proiect.programpoliclinica (ID_Program, Zi_Saptamana, ID_Policlinica) VALUES
(1, 'Luni', 1),
(2, 'Marti', 1),
(3, 'Miercuri', 1),
(4, 'Joi', 1),
(5, 'Vineri', 1);



INSERT INTO proiect.rapoartemedicale ( ID_Raport, Continut, ID_Programare, ID_Asistent,ID_Medic) VALUES
( 1, 'Pacientul a fost consultat si i s-a recomandat interventia chirurgicala.', 1, 1,1),
( 2, 'Pacientul a fost diagnosticat cu problema ortopedica si va necesita interventie.', 2, 2,2);


INSERT INTO proiect.serviciidisponibile (ID_ServiciiDisponibile, Grad, Cost, Durata) VALUES
(1, 1,  1150, 30),
(2, 2, 1180, 45);


INSERT INTO proiect.serviciispecifice (ID_SerciviiSpecifice, NumeSpecialitate, CompetenteleMedicului, PretulServiciului, DurataServiciului) VALUES
(1, 'Chirurgie generala', 1, 80, 60),
(2, 'Ortopedie si traumatologie', 2, 100, 75);