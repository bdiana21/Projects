CREATE DEFINER=`root`@`localhost` PROCEDURE `CalculProfitPoliclinica2`(IN medicID INT)
BEGIN
    DECLARE policlinicaProfit DECIMAL(10, 2);

    -- Calculează profitul policlinicii pentru medic
    SELECT SUM(p.Valoare) AS ProfitPoliclinica
    INTO policlinicaProfit
    FROM proiect.programari pr
    JOIN proiect.bonurifiscale p ON pr.ID_Programare = p.ID_Programare
    WHERE pr.ID_Medic = medicID;

    -- Afișează profitul policlinicii pentru medic
    SELECT policlinicaProfit AS ProfitPoliclinica;
END